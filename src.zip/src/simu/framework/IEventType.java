package simu.framework;

/**
 * Interface for event types.
 */
public interface IEventType { }
