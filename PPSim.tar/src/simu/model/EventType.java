package simu.model;

import simu.framework.IEventType;

public enum EventType implements IEventType {
    ARR, DEP, DEP1, DEP2, DEP3, DEP4
}
