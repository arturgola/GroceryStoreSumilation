package simu.framework;

public interface IEventType { }
