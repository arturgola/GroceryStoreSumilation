First push.


How to run:  
Build project with SDK, in the menu bar, select build project and use oracle SDK.  
import jfreechart lib into project. In the menu - File, Project Structure and then choose Libraries and local jfreechart  
run from Main (/scr/Main).   
Insert 10000 as a simu time or more. Charts can show current time. Just point on them with pointer, make longer simu time to view better.  
UI is located in View, Controller acts as a controller between engine and GUI.  
Framework is a basic engine from teacher with changes.  

# TODO

We need working methods of reset, pause, speed down/up.  This changes must be done somewhere in MyEngine.java (/src/model).  
We need documentation.  
If there will be enough time, we need to work with improvement of GUI.  

<p align="center">
    <img src="./demo_picture.png" />
</p>
